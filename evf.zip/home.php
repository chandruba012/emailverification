<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style1.css">

</head>
<body>

<!-- custom cursors  -->
<div class="cursor-1"></div>
<div class="cursor-2"></div>


<div id="menu-bars" class="fas fa-bars"></div>
    
<!-- header section starts  -->

<header>

    <a href="#" class="logo"> <span>chandrashekhar</span>  </a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
        <!-- <a href="#service">service</a> -->
        <a href="#experience">experience</a>
        <a href="#portfolio">portfolio</a>
        <a href="#contact">contact</a>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Log Out</a>
            </li>
        </ul>
    </nav>

    <!-- <div class="follow">
        <a href="#" class="fab fa-facebook-f"></a>
        <a href="#" class="fab fa-twitter"></a>
        <a href="#" class="fab fa-instagram"></a>
        <a href="#" class="fab fa-linkedin"></a>
    </div> -->

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="content">
        <span class="hi"> hi there... </span>
        <h3> i am <span> Chandrashekhar </span> </h3>
        <p class="info"> i am a Web Developer </p>
      <!--  <p class="text"> To work in a challenging environment providing opportunity to explore my full potential with continuous addition to the learning curve and utilize my skills towards the benifit of the organisation </p>
         <a href="#about" class="btn">about me</a> -->
    </div>

    <div class="image">
        <img src="images/frontend.jpg" alt="">
    </div>

</section>

<!-- home section ends -->

<!-- about section starts  -->

<section class="about" id="about">

<h1 class="heading" > about <span> me </span> </h1>

<div class="row-1">

    <!-- <div class="image">
        <img src="images/chandru.JPEG" alt="">
    </div> -->

    <div class="content">
        <h3> my name is chandrashekhar & i am a Web Developer </h3>
        <!-- <p>To work in a challenging environment providing opportunity to explore my full potential with continuous addition to the learning curve and utilize my skills towards the benifit of the organisation</p> -->
        <div class="box-container">
            <div class="box">
                <p> <span>  Name : </span> Chandrashekhar </p>
                <p> <span> age : </span> 29 </p>
                <p> <span> gender : </span> male </p>
                <p> <span> language : </span>Kannada, hindi, english </p>
            </div>
            <div class="box">
                <p> <span> work : </span> Web Developer </p>
                <p> <span> phone : </span> +91-7795351469 </p>
                <p style="text-transform:lowercase"> <span> email : </span> chanadruallolli@gmail.com </p>
                <p> <span> country : </span> india </p>
            </div>
        <!-- </div>
        <a target="_blank" href="https://drive.google.com/file/d/14Lj9rkDs_E1KLtmSWDQ0IMBynhjBOpZ2/view?usp=drive_link"class="btn">download CV</a>
       <a href="login.php" class="btn">hire me</a>
    </div> -->

</div>

<h1 class="heading"> <span> my </span> skills </h1>

<div class="row-2">

    <div class="skills">
        <div class="progress">
            <h3> HTML <span> 95% </span> </h3>
            <div class="bar"> <span></span> </div>
        </div>
        <div class="progress">
            <h3> Css <span> 80% </span> </h3>
            <div class="bar"> <span></span> </div>
        </div>
        <div class="progress">
            <h3> Javascript <span> 70% </span> </h3>
            <div class="bar"> <span></span> </div>
        </div>
        <!-- <div class="progress">
            <h3> React JS <span> 60% </span> </h3>
            <div class="bar"> <span></span> </div>
        </div> -->
    </div>

    <div class="box-container">

        <div class="box">
            <h3> >> 1+</h3>
            <p>years of experience</p>
        </div>
        <!-- <div class="box">
            <h3> >> 250+ </h3>
            <p>happy clients</p>
        </div> -->
        <div class="box">
            <h3> >> 13</h3>
            <p>projects completed</p>
        </div>
        <!-- <div class="box">
            <h3> >> 12+ </h3>
            <p>awards won</p>
        </div> -->

    </div>

</div>

</section>

<!-- about section ends -->

<!-- service section starts  -->

<!-- <section class="service" id="service">

<h1 class="heading"> <span> my </span> services </h1>

    <div class="box-container">

        <div class="box">
            <i class="fas fa-code"></i>
            <h3>web design</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit, facere?</p>
        </div>

        <div class="box">
            <i class="fas fa-paint-brush"></i>
            <h3>graphic design</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit, facere?</p>
        </div>

        <div class="box">
            <i class="fas fa-mobile"></i>
            <h3>responsive design</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit, facere?</p>
        </div>

        <div class="box">
            <i class="fas fa-bullhorn"></i>
            <h3>seo marketing</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit, facere?</p>
        </div>

        <div class="box">
            <i class="fas fa-chart-line"></i>
            <h3>digital marketing</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit, facere?</p>
        </div>

        <div class="box">
            <i class="fas fa-envelope"></i>
            <h3>email marketing</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit, facere?</p>
        </div>

    </div>

</section> -->

<!-- service section ends -->

<!-- experience section starts  -->

<section class="experience" id="experience">

    <h1 class="heading">  my <span> experience</span> </h1>

    <div class="box-container">

        <!-- <div class="box">
            <div class="content">
                <span> 2015 - 2016 </span>
                <h3>front-end development</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae vel quasi consectetur expedita ipsam similique maiores ipsa? Error, debitis ullam.</p>
            </div>
        </div>

        <div class="box">
            <div class="content">
                <span> 2016 - 2017 </span>
                <h3>front-end development</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae vel quasi consectetur expedita ipsam similique maiores ipsa? Error, debitis ullam.</p>
            </div>
        </div> -->

        <!-- <div class="box">
            <div class="content">
                <span> 2018 - 2021 </span>
                <h3>quality analist</h3>
                <p>QA ensures the products or services meet specific quality standards through the 7 Quality Control Tools. </p>
            </div>
        </div> -->

        <div class="box">
            <div class="content">
                <span> 2023 - 2024 </span>
                <h3>Web Development</h3>
                <p>I have developed strong skills in HTML, CSS, and JavaScript, and have hands-on experience in responsive web design through various projects.</p>
            </div>
        </div>

        <!-- <div class="box">
            <div class="content">
                <span> 2019 - 2020 </span>
                <h3>front-end development</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae vel quasi consectetur expedita ipsam similique maiores ipsa? Error, debitis ullam.</p>
            </div>
        </div>

        <div class="box">
            <div class="content">
                <span> 2020 - 2021 </span>
                <h3>front-end development</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae vel quasi consectetur expedita ipsam similique maiores ipsa? Error, debitis ullam.</p>
            </div>
        </div> -->

    </div>

</section>

<!-- experience section ends -->

<!-- portfolio section starts  -->

<section class="portfolio" id="portfolio">

    <h1 class="heading"> <span> my </span> projects </h1>

    <div class="box-container">

        <div class="box">
            <img src="images/notesapp.jpg" alt="">
            <h3> Notes app</h3>
            <div class="icons">
                <a href="#" class="fas fa-link"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-search"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/portfolio image.webp" alt="">
            <h3> personal portfolio </h3>
            <div class="icons">
                <a href="#" class="fas fa-link"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-search"></a>
            </div>
        </div>

        <!-- <div class="box">
            <img src="images/img-3.jpg" alt="">
            <h3> project 03 </h3>
            <div class="icons">
                <a href="#" class="fas fa-link"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-search"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/img-4.jpg" alt="">
            <h3> project 04 </h3>
            <div class="icons">
                <a href="#" class="fas fa-link"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-search"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/img-5.jpg" alt="">
            <h3> project 05 </h3>
            <div class="icons">
                <a href="#" class="fas fa-link"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-search"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/img-6.jpg" alt="">
            <h3> project 06 </h3>
            <div class="icons">
                <a href="#" class="fas fa-link"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-search"></a>
            </div>
        </div> -->

    </div>

</section>

<!-- portfolio section ends -->

<!-- contact section starts  -->

<section class="contact" id="contact">

    <h1 class="heading"> contact <span> me </span> </h1>

    <div class="icons-container">

        <div class="icons">
            <i class="fas fa-envelope"></i>
            <h3>my email</h3>
            <p style="text-transform:lowercase">chandruallolli@gmail.com</p>
            <!-- <p>chandruallolli@gmail.com</p> -->
        </div>

        <div class="icons">
            <i class="fas fa-phone"></i>
            <h3>my number</h3>
            <p>+91-7795351469</p>
            <!-- <p>+111-222-3333</p> -->
        </div>

        <div class="icons">
            <i class="fas fa-map-marker-alt"></i>
            <h3>my address</h3>
            <p>Chamundeshwari nagar, Begur, bangalore, india - 560076</p>
        </div>

    </div>

    <div class="row">

      <!--  <form action="">

            <input type="text" placeholder="name" class="box">
            <input type="email" placeholder="email" class="box">
            <input type="number" placeholder="mobile-number" class="box">

            <textarea name="" placeholder="message" id="" cols="30" rows="10"></textarea>

            <input type="submit" class="btn" value="send message">

        </form> -->

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7778.855682867934!2d77.60947455869142!3d12.880187770983465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae14c9f5d99093%3A0xf37fc41ab8ebaa2e!2sDevarachikkana%20Halli%2C%20Bengaluru%2C%20Karnataka%20560076!5e0!3m2!1sen!2sin!4v1721321870956!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>


</section>

<!-- contact section ends -->

<!-- footer section  -->
<!-- <footer class="footer"> created by <span> mr. web designer </span> | all rights reserved! </footer> -->






















<!-- custom js file link  -->
<script src="resscrpt.js"></script>

</body>
</html>