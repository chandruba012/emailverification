<?php
session_start();
include "connection.php";
// $conn = mysqli_connect('localhost', 'root', '', 'emailv');

$email=$_SESSION['email'];
$otp=$_POST['otp'];
$sql="Select * from members where email='$email' and otp='$otp'";
$rs=mysqli_query($conn,$sql)or die(mysqli_error($conn));
if(mysqli_num_rows($rs)>0){
    // $rs=mysqli_query($conn,$sql)or die(mysqli_error($conn));
    // header("location:home.php?msg=Welcome User:".$email."Login Success!!");
    echo "
    <script>
        alert('Welcome User:".$email." your account registered Successfully!!');
        window.location.href = 'http://localhost/cba/emailv/index.php';
    </script>
    ";
}
    else{
            $delete = "DELETE FROM members WHERE email='$email'";
            mysqli_query($conn, $delete);
        // $rs=mysqli_query($conn,$sql)or die(mysqli_error($conn));
        echo "
        <script>
            alert('OTP is Invalid, Please register Again!!');
            window.location.href = 'http://localhost/cba/emailv/register.php';
        </script>
        ";
            // header("location:register.php?msg=OTP is Invalid Plz try Again!!");
            
    }
    ?>