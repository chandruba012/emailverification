# Login-Registration-form-with-PhpMailer-Password-Reset
- This project is a login and register form using PHPMailer forgot-password reset, which sends a code reset in user's email. It also has a search button that allows you to check whether one is registered or not. It uses Javascript for form validation and Php for server connection.
- Use the userform.sql file, run it directly on the xampp database to get the actual tables for this code.
- Ensure you use an active gmail account.
- Incase the email  mailtest8782@gmail.com on mail.php file fails to send code, you can create yours by heading to manage my account (your email account) then security and finally on the 2 step verification and app passwords section. Ensure the toggle button on 2 step verification is on then generate a password which google will show you. Copy the password into your mail.php file in the password area. 
