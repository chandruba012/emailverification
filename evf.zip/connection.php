<?php
$conn = mysqli_connect('localhost', 'root', '', 'emailv');
if (!$conn) {
	die("Connection failed".mysqli_connect_error());
}
?>